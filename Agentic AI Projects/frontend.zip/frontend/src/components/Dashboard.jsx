import React, { useState } from 'react';
import Upload from './Upload';
import AgentFeed from './AgentFeed';
import Results from './Results';

const Dashboard = () => {
    const [processing, setProcessing] = useState(false);
    const [results, setResults] = useState(null);
    const [currentAgent, setCurrentAgent] = useState(null);

    const handleUpload = async (file) => {
        setProcessing(true);
        setResults(null);
        setCurrentAgent("Extractor Agent is analyzing the image...");

        const formData = new FormData();
        formData.append('file', file);

        try {
            // Simulate agent progression for UI effect
            const agentSteps = [
                "Extractor Agent: Reading invoice data...",
                "Validator Agent: Checking math and dates...",
                "Categorizer Agent: Classifying expense...",
                "Auditor Agent: Calculating risk score...",
                "Analyst Agent: Generating insights...",
            ];

            let step = 0;
            const interval = setInterval(() => {
                if (step < agentSteps.length) {
                    setCurrentAgent(agentSteps[step]);
                    step++;
                }
            }, 1500);

            // Use 127.0.0.1 to avoid localhost resolution issues
            const response = await fetch('http://127.0.0.1:8000/process', {
                method: 'POST',
                body: formData,
            });

            clearInterval(interval);

            if (!response.ok) {
                throw new Error('Processing failed');
            }

            const data = await response.json();
            setResults(data);
            setCurrentAgent("All agents completed successfully.");
        } catch (error) {
            console.error(error);
            setCurrentAgent("Error: " + error.message);
        } finally {
            setProcessing(false);
        }
    };

    return (
        <div className="flex flex-col min-h-[calc(100vh-8rem)]">
            <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                {/* Left Column: Input & Status */}
                <div className="lg:col-span-4 space-y-8 sticky top-0">
                    <div className="glass-card rounded-2xl p-1">
                        <Upload onUpload={handleUpload} disabled={processing} />
                    </div>
                    <AgentFeed currentStatus={currentAgent} isProcessing={processing} />
                </div>

                {/* Right Column: Results */}
                <div className="lg:col-span-8">
                    <Results data={results} />
                </div>
            </div>

            {/* Footer */}
            <footer className="mt-12 py-6 border-t border-gray-800 text-center text-gray-500 text-sm">
                <p>Powered by Google Gemini 1.5 Flash & LangGraph</p>
                <div className="flex justify-center space-x-4 mt-2">
                    <a href="#" className="hover:text-blue-400 transition-colors">Documentation</a>
                    <span>•</span>
                    <a href="#" className="hover:text-blue-400 transition-colors">Privacy Policy</a>
                    <span>•</span>
                    <a href="#" className="hover:text-blue-400 transition-colors">Support</a>
                </div>
            </footer>
        </div>
    );
};

export default Dashboard;
