import React, { useEffect, useRef } from 'react';

const AgentFeed = ({ currentStatus, isProcessing }) => {
    const scrollRef = useRef(null);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [currentStatus]);

    return (
        <div className="glass-card rounded-2xl p-1 overflow-hidden h-80 flex flex-col">
            {/* Terminal Header */}
            <div className="bg-gray-900/80 px-4 py-2 flex items-center justify-between border-b border-gray-800">
                <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
                </div>
                <div className="text-xs font-mono text-gray-500">agent_system.log</div>
            </div>

            {/* Terminal Body */}
            <div className="flex-1 bg-gray-950/90 p-4 font-mono text-sm overflow-y-auto custom-scrollbar" ref={scrollRef}>
                {!isProcessing && !currentStatus && (
                    <div className="text-gray-600 italic flex items-center">
                        <span className="mr-2">$</span>
                        <span>System ready. Waiting for input...</span>
                    </div>
                )}

                {isProcessing && (
                    <div className="space-y-2">
                        <div className="text-gray-500 flex items-center">
                            <span className="mr-2 text-green-500">$</span>
                            <span>Initializing multi-agent workflow...</span>
                        </div>
                        {currentStatus && (
                            <div className="flex items-start space-x-2 animate-pulse text-blue-400">
                                <span className="text-green-500">➜</span>
                                <span>{currentStatus}</span>
                                <span className="animate-ping inline-flex h-2 w-2 rounded-full bg-blue-400 opacity-75 ml-2 mt-1.5"></span>
                            </div>
                        )}
                    </div>
                )}

                {!isProcessing && currentStatus && (
                    <div className="text-green-400 flex items-center">
                        <span className="mr-2">$</span>
                        <span>{currentStatus}</span>
                    </div>
                )}
            </div>
        </div>
    );
};

export default AgentFeed;
