import React, { useEffect, useState } from 'react';

const Results = ({ data }) => {
    const [animatedScore, setAnimatedScore] = useState(0);

    useEffect(() => {
        if (data?.audit_result?.risk_score) {
            let start = 0;
            const end = data.audit_result.risk_score;
            const duration = 1000;
            const increment = end / (duration / 16); // 60fps

            const timer = setInterval(() => {
                start += increment;
                if (start >= end) {
                    setAnimatedScore(end);
                    clearInterval(timer);
                } else {
                    setAnimatedScore(Math.floor(start));
                }
            }, 16);

            return () => clearInterval(timer);
        }
    }, [data]);

    if (!data) {
        return (
            <div className="glass-card rounded-2xl p-8 h-full flex flex-col items-center justify-center text-gray-500 space-y-4 border-dashed border-2 border-gray-700/50">
                <div className="w-16 h-16 rounded-full bg-gray-800/50 flex items-center justify-center">
                    <svg className="w-8 h-8 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                </div>
                <p>Upload an invoice to see AI analysis results</p>
            </div>
        );
    }

    const { extracted_data, validation_result, categorization_result, audit_result, analysis_result } = data;

    const getRiskColor = (score) => {
        if (score < 30) return "text-green-400";
        if (score < 70) return "text-yellow-400";
        return "text-red-400";
    };

    const getRiskBg = (score) => {
        if (score < 30) return "bg-green-500/10 border-green-500/20";
        if (score < 70) return "bg-yellow-500/10 border-yellow-500/20";
        return "bg-red-500/10 border-red-500/20";
    };

    return (
        <div className="space-y-8 animate-fade-in">
            {/* Top Row: Summary & Risk */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2 glass-card rounded-2xl p-6 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2 group-hover:bg-blue-500/20 transition-all duration-500"></div>
                    <h2 className="text-lg font-semibold text-blue-400 mb-3 flex items-center">
                        <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        Executive Summary
                    </h2>
                    <p className="text-gray-300 text-sm leading-relaxed relative z-10">{analysis_result?.summary}</p>
                    <div className="mt-6 flex flex-wrap gap-3">
                        <span className="px-3 py-1 bg-blue-500/10 text-blue-300 rounded-full text-xs font-medium border border-blue-500/20 flex items-center">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-400 mr-2"></span>
                            {categorization_result?.category}
                        </span>
                        <span className="px-3 py-1 bg-purple-500/10 text-purple-300 rounded-full text-xs font-medium border border-purple-500/20 flex items-center">
                            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mr-2"></span>
                            {categorization_result?.department}
                        </span>
                    </div>
                </div>

                <div className={`glass-card rounded-2xl p-6 flex flex-col items-center justify-center relative overflow-hidden ${getRiskBg(audit_result?.risk_score)}`}>
                    <h2 className="text-sm font-semibold text-gray-400 mb-2 uppercase tracking-wider">Risk Score</h2>
                    <div className={`text-6xl font-bold ${getRiskColor(audit_result?.risk_score)} tabular-nums`}>
                        {animatedScore}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">out of 100</div>

                    <div className="mt-4 w-full">
                        {audit_result?.flags?.length > 0 ? (
                            <div className="space-y-1">
                                {audit_result.flags.slice(0, 2).map((flag, i) => (
                                    <div key={i} className="flex items-center text-xs text-red-300 bg-red-500/10 px-2 py-1 rounded">
                                        <span className="mr-1">⚠</span> {flag}
                                    </div>
                                ))}
                                {audit_result.flags.length > 2 && (
                                    <div className="text-xs text-center text-gray-400">+{audit_result.flags.length - 2} more</div>
                                )}
                            </div>
                        ) : (
                            <div className="text-xs text-green-400 bg-green-500/10 px-3 py-1 rounded-full border border-green-500/20 flex items-center justify-center">
                                <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                                Safe
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Extracted Data Table */}
            <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-semibold text-white flex items-center">
                        <svg className="w-5 h-5 mr-2 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                        Extracted Data
                    </h2>
                    <div className="text-sm text-gray-400">
                        ID: <span className="font-mono text-gray-300">{extracted_data?.invoice_number}</span>
                    </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                    <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700/50">
                        <span className="block text-xs text-gray-500 uppercase tracking-wider mb-1">Vendor</span>
                        <span className="font-medium text-white text-lg truncate block" title={extracted_data?.vendor_name}>{extracted_data?.vendor_name}</span>
                    </div>
                    <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700/50">
                        <span className="block text-xs text-gray-500 uppercase tracking-wider mb-1">Date</span>
                        <span className="font-medium text-white text-lg">{extracted_data?.date}</span>
                    </div>
                    <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700/50">
                        <span className="block text-xs text-gray-500 uppercase tracking-wider mb-1">Total Amount</span>
                        <span className="font-bold text-green-400 text-xl">${extracted_data?.total_amount}</span>
                    </div>
                    <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700/50">
                        <span className="block text-xs text-gray-500 uppercase tracking-wider mb-1">Items</span>
                        <span className="font-medium text-white text-lg">{extracted_data?.line_items?.length || 0}</span>
                    </div>
                </div>

                <div className="overflow-hidden rounded-xl border border-gray-700/50">
                    <table className="w-full text-left text-sm text-gray-300">
                        <thead className="bg-gray-800/80 text-gray-400 uppercase font-medium text-xs">
                            <tr>
                                <th className="px-6 py-4">Description</th>
                                <th className="px-6 py-4 text-right">Qty</th>
                                <th className="px-6 py-4 text-right">Unit Price</th>
                                <th className="px-6 py-4 text-right">Amount</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-800 bg-gray-900/30">
                            {extracted_data?.line_items?.map((item, index) => (
                                <tr key={index} className="hover:bg-gray-800/50 transition-colors">
                                    <td className="px-6 py-4 font-medium text-white">{item.description}</td>
                                    <td className="px-6 py-4 text-right text-gray-400">{item.quantity}</td>
                                    <td className="px-6 py-4 text-right text-gray-400">${item.unit_price}</td>
                                    <td className="px-6 py-4 text-right font-medium text-white">${item.amount}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Insights */}
            <div className="glass-card rounded-2xl p-6 border-l-4 border-indigo-500">
                <h2 className="text-lg font-semibold mb-4 text-indigo-300 flex items-center">
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    Analyst Insights
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {analysis_result?.insights?.map((insight, i) => (
                        <div key={i} className="flex items-start space-x-3 bg-indigo-500/5 p-3 rounded-lg border border-indigo-500/10">
                            <span className="text-indigo-400 mt-0.5 text-lg">•</span>
                            <span className="text-gray-300 text-sm leading-relaxed">{insight}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Results;
