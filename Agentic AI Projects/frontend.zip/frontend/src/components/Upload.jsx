import React, { useState } from 'react';

const Upload = ({ onUpload, disabled }) => {
    const [dragActive, setDragActive] = useState(false);

    const handleDrag = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === "dragenter" || e.type === "dragover") {
            setDragActive(true);
        } else if (e.type === "dragleave") {
            setDragActive(false);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        e.stopPropagation();
        setDragActive(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            onUpload(e.dataTransfer.files[0]);
        }
    };

    const handleChange = (e) => {
        e.preventDefault();
        if (e.target.files && e.target.files[0]) {
            onUpload(e.target.files[0]);
        }
    };

    return (
        <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-1 shadow-xl border border-gray-700/50">
            <div className="bg-gray-900/50 rounded-xl p-6">
                <h2 className="text-xl font-bold mb-4 flex items-center text-white">
                    <span className="w-8 h-8 bg-blue-500/20 text-blue-400 rounded-lg flex items-center justify-center mr-3 text-sm">01</span>
                    Upload Invoice
                </h2>
                <div
                    className={`relative border-2 border-dashed rounded-xl p-10 text-center transition-all duration-300 ease-in-out ${dragActive
                            ? "border-blue-500 bg-blue-500/10 scale-[1.02]"
                            : "border-gray-600 hover:border-gray-500 hover:bg-gray-800/50"
                        } ${disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                >
                    <input
                        type="file"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        onChange={handleChange}
                        disabled={disabled}
                        accept=".pdf,.jpg,.jpeg,.png"
                    />
                    <div className="flex flex-col items-center justify-center space-y-4">
                        <div className={`p-4 rounded-full transition-colors ${dragActive ? "bg-blue-500/20 text-blue-400" : "bg-gray-800 text-gray-400"}`}>
                            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                            </svg>
                        </div>
                        <div>
                            <p className="text-gray-200 font-medium text-lg">Drop your invoice here</p>
                            <p className="text-sm text-gray-500 mt-1">or click to browse</p>
                        </div>
                        <div className="flex gap-2 mt-2">
                            <span className="px-2 py-1 bg-gray-800 rounded text-xs text-gray-500 border border-gray-700">PDF</span>
                            <span className="px-2 py-1 bg-gray-800 rounded text-xs text-gray-500 border border-gray-700">JPG</span>
                            <span className="px-2 py-1 bg-gray-800 rounded text-xs text-gray-500 border border-gray-700">PNG</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Upload;
